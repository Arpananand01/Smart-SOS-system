import express from 'express';
import cors from 'cors';
import twilio from 'twilio';

const app = express();
const PORT = process.env.PORT || 3001;

// Initialize Twilio client
const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/', (_req, res) => {
  res.json({ status: 'ok', service: 'sos-backend' });
});

// Receive alert payload and simulate dispatch
app.post('/api/send-alerts', async (req, res) => {
  try {
    const payload = req.body || {};
    console.log('[send-alerts] incoming payload');
    console.dir(payload, { depth: 2 });
    // Here you would integrate WhatsApp/SMS/email providers.
    res.json({ ok: true });
  } catch (e) {
    console.error('Error in /api/send-alerts', e);
    res.status(500).json({ error: 'internal_error' });
  }
});

// Google Maps Reverse Geocoding API
app.post('/api/reverse-geocode', async (req, res) => {
  try {
    const { lat, lon } = req.body || {};
    if (!lat || !lon) {
      return res.status(400).json({ error: 'lat and lon required' });
    }
    
    // Replace with your Google Maps API key
    const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY || '';
    
    if (!GOOGLE_MAPS_API_KEY) {
      console.log('[reverse-geocode] No Google Maps API key, using fallback');
      return res.json({ address: '' });
    }
    
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lon}&key=${GOOGLE_MAPS_API_KEY}`;
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.status === 'OK' && data.results && data.results[0]) {
      const result = data.results[0];
      const address = result.formatted_address || '';
      console.log(`[reverse-geocode] ${lat},${lon} -> ${address}`);
      res.json({ address });
    } else {
      console.log(`[reverse-geocode] API error: ${data.status}`);
      res.json({ address: '' });
    }
  } catch (e) {
    console.error('Error in /api/reverse-geocode', e);
    res.status(500).json({ error: 'internal_error' });
  }
});

// SMS endpoint with Twilio integration
app.post('/send-sos', async (req, res) => {
  try {
    const { to, message } = req.body || {};
    
    // Validate required fields
    if (!to || !message) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing required fields: to and message' 
      });
    }
    
    // Validate Twilio credentials
    if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN || !process.env.TWILIO_PHONE) {
      console.error('[send-sos] Twilio credentials not configured');
      return res.status(500).json({ 
        success: false, 
        error: 'SMS service not configured. Please check server settings.' 
      });
    }
    
    console.log(`[send-sos] Sending SMS to ${to}, message length: ${message.length}`);
    
    // Send SMS via Twilio
    const messageResult = await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE,
      to: to
    });
    
    console.log(`[send-sos] SMS sent successfully. SID: ${messageResult.sid}`);
    
    res.json({ 
      success: true, 
      sid: messageResult.sid,
      to: to,
      status: messageResult.status
    });
    
  } catch (error) {
    console.error('[send-sos] Error sending SMS:', error);
    
    // Handle specific Twilio errors
    let errorMessage = 'Failed to send SMS';
    let statusCode = 500;
    
    if (error.code === 21211) {
      errorMessage = 'Invalid phone number format. Please check the number.';
      statusCode = 400;
    } else if (error.code === 21214) {
      errorMessage = 'Phone number not verified. In trial mode, you can only send SMS to verified numbers.';
      statusCode = 400;
    } else if (error.code === 21610) {
      errorMessage = 'Phone number is not a valid mobile number.';
      statusCode = 400;
    } else if (error.code === 21614) {
      errorMessage = 'Invalid phone number. Please check the format.';
      statusCode = 400;
    } else if (error.code === 63007) {
      errorMessage = 'SMS service temporarily unavailable. Please try again later.';
      statusCode = 503;
    }
    
    res.status(statusCode).json({ 
      success: false, 
      error: errorMessage,
      code: error.code || 'unknown'
    });
  }
});

app.listen(PORT, () => {
  console.log(`sos-backend listening on http://localhost:${PORT}`);
});
